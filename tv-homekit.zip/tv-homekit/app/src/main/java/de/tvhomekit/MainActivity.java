package de.tvhomekit;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.text.InputType;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;

public class MainActivity extends Activity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private PrefsAuthInfo auth;
    private TextView statusView;

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            statusView.setText(statusText());
            handler.postDelayed(this, 2000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SharedPreferences p = getSharedPreferences("tvhk", MODE_PRIVATE);
        auth = new PrefsAuthInfo(this);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(48, 24, 48, 24);
        root.setBackgroundColor(Color.parseColor("#202124"));

        root.addView(label("Apple Home: + > Gerät hinzufügen > diesen Code scannen", 20));

        ImageView qr = new ImageView(this);
        qr.setImageBitmap(qrBitmap(auth.setupPayload(), 320));
        root.addView(qr, new LinearLayout.LayoutParams(320, 320));

        root.addView(label("Setup-Code: " + auth.getPin(), 20));

        statusView = label(statusText(), 16);
        root.addView(statusView);

        EditText host = field("TV-IP im WLAN (nicht 127.0.0.1)", p.getString("host", "127.0.0.1"), false);
        EditText psk = field("Pre-Shared Key der IP-Steuerung", p.getString("psk", ""), true);
        root.addView(host);
        root.addView(psk);

        Button save = new Button(this);
        save.setText("Speichern & Neustart");
        save.setOnClickListener(v -> {
            p.edit().putString("host", host.getText().toString().trim())
                    .putString("psk", psk.getText().toString()).apply();
            restart("Gespeichert. App startet neu - danach bitte wieder öffnen.");
        });
        root.addView(save);

        Button reset = new Button(this);
        reset.setText("Pairing zurücksetzen (neuer QR-Code)");
        reset.setOnClickListener(v -> {
            auth.resetPairing();
            restart("Zurückgesetzt. App startet neu - danach bitte wieder öffnen.");
        });
        root.addView(reset);

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Color.parseColor("#202124"));
        sv.addView(root);
        setContentView(sv);

        startForegroundService(new Intent(this, HomeKitService.class));
    }

    @Override protected void onResume() { super.onResume(); handler.post(tick); }
    @Override protected void onPause() { super.onPause(); handler.removeCallbacks(tick); }

    private String statusText() {
        return "HomeKit-Server: " + Status.server
                + "\nNetzwerk: " + Status.ifaces
                + "\nGekoppelt: " + (auth.hasUser() ? "ja" : "nein")
                + "\nTV-Steuerung: " + Status.tv;
    }

    /** Beendet den Prozess; der Hintergrunddienst wird von Android neu gestartet. */
    private void restart(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
        handler.postDelayed(() -> Process.killProcess(Process.myPid()), 1500);
    }

    private TextView label(String s, int sp) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(Color.WHITE);
        t.setPadding(0, 10, 0, 10);
        return t;
    }

    private EditText field(String hint, String value, boolean secret) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setText(value);
        e.setTextColor(Color.WHITE);
        e.setHintTextColor(Color.GRAY);
        e.setSingleLine(true);
        if (secret) e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        return e;
    }

    private static Bitmap qrBitmap(String text, int size) {
        try {
            BitMatrix m = new QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size);
            Bitmap b = Bitmap.createBitmap(size, size, Bitmap.Config.RGB_565);
            for (int x = 0; x < size; x++)
                for (int y = 0; y < size; y++)
                    b.setPixel(x, y, m.get(x, y) ? Color.BLACK : Color.WHITE);
            return b;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
