package de.tvhomekit;

/** Einfacher Statusspeicher, damit die Oberflaeche zeigen kann, was im Hintergrund passiert. */
public class Status {
    public static volatile String server = "noch nicht gestartet";
    public static volatile String ifaces = "-";
    public static volatile String tv = "noch keine Abfrage";
}
