package de.tvhomekit;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;
import io.github.hapjava.server.HomekitAuthInfo;
import io.github.hapjava.server.impl.HomekitServer;
import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.Locale;

/** Speichert Pairing-Daten (Schluessel, PIN, gekoppelte iPhones) in SharedPreferences. */
public class PrefsAuthInfo implements HomekitAuthInfo {
    private final SharedPreferences p;

    public PrefsAuthInfo(Context c) {
        p = c.getSharedPreferences("tvhk", Context.MODE_PRIVATE);
        if (!p.contains("mac")) {
            try {
                p.edit()
                        .putString("mac", HomekitServer.generateMac())
                        .putString("salt", HomekitServer.generateSalt().toString())
                        .putString("key", Base64.encodeToString(HomekitServer.generateKey(), Base64.NO_WRAP))
                        .putString("pin", randomPin())
                        .apply();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
    }

    private static String randomPin() {
        SecureRandom r = new SecureRandom();
        String d;
        do {
            d = String.format(Locale.US, "%08d", r.nextInt(100000000));
        } while (d.matches("(\\d)\\1{7}") || d.equals("12345678") || d.equals("87654321"));
        return d.substring(0, 3) + "-" + d.substring(3, 5) + "-" + d.substring(5);
    }

    /** Inhalt des Setup-QR-Codes (Kategorie 31 = Fernseher, IP-Pairing). */
    public String setupPayload() {
        long code = Long.parseLong(getPin().replace("-", ""));
        long v = (31L << 31) | (2L << 27) | code;
        String s = Long.toString(v, 36).toUpperCase(Locale.US);
        while (s.length() < 9) s = "0" + s;
        return "X-HM://" + s + getSetupId();
    }

    public String getPin() { return p.getString("pin", ""); }
    public String getSetupId() { return "TVHK"; }
    public String getMac() { return p.getString("mac", ""); }
    public BigInteger getSalt() { return new BigInteger(p.getString("salt", "0")); }
    public byte[] getPrivateKey() { return Base64.decode(p.getString("key", ""), Base64.NO_WRAP); }

    public void createUser(String username, byte[] publicKey) {
        p.edit().putString("u_" + username, Base64.encodeToString(publicKey, Base64.NO_WRAP)).apply();
    }
    public void createUser(String username, byte[] publicKey, boolean isAdmin) {
        createUser(username, publicKey);
    }
    public void removeUser(String username) { p.edit().remove("u_" + username).apply(); }
    public byte[] getUserPublicKey(String username) {
        String s = p.getString("u_" + username, null);
        return s == null ? null : Base64.decode(s, Base64.NO_WRAP);
    }
    public boolean hasUser() {
        for (String k : p.getAll().keySet()) if (k.startsWith("u_")) return true;
        return false;
    }
    public boolean userIsAdmin(String username) { return true; }
}
