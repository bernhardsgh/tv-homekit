package de.tvhomekit;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.wifi.WifiManager;
import android.os.IBinder;
import android.util.Log;
import io.github.hapjava.server.impl.HomekitRoot;
import io.github.hapjava.server.impl.HomekitServer;
import java.io.IOException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Collections;

public class HomeKitService extends Service {
    private static final String TAG = "TvHomeKit";
    private volatile HomekitRoot root;
    private HomekitServer server;
    private WifiManager.MulticastLock lock;

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (root != null) return START_STICKY;
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(
                new NotificationChannel("tvhk", "HomeKit", NotificationManager.IMPORTANCE_LOW));
        startForeground(1, new Notification.Builder(this, "tvhk")
                .setContentTitle("HomeKit-Bridge laeuft")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .build());
        new Thread(this::startServer, "hap-start").start();
        return START_STICKY;
    }

    private void startServer() {
        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
            lock = wm.createMulticastLock("tvhk");
            lock.setReferenceCounted(false);
            lock.acquire();

            SharedPreferences p = getSharedPreferences("tvhk", MODE_PRIVATE);
            SonyTv tv = new SonyTv(p.getString("host", "127.0.0.1"), p.getString("psk", ""));

            server = new HomekitServer(localAddress(), 9123);
            HomekitRoot r = server.createStandaloneAccessory(new PrefsAuthInfo(this), new TvSwitch(tv));
            r.start();
            root = r;
            Log.i(TAG, "HomeKit-Server gestartet");
        } catch (Exception e) {
            Log.e(TAG, "Start fehlgeschlagen", e);
        }
    }

    private static InetAddress localAddress() throws IOException {
        for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
            if (!ni.isUp() || ni.isLoopback()) continue;
            for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                if (a instanceof Inet4Address && a.isSiteLocalAddress()) return a;
            }
        }
        throw new IOException("Keine lokale IPv4-Adresse gefunden");
    }

    @Override
    public void onDestroy() {
        try {
            if (root != null) root.stop();
            if (server != null) server.stop();
        } catch (Exception ignored) { }
        if (lock != null && lock.isHeld()) lock.release();
        super.onDestroy();
    }
}
