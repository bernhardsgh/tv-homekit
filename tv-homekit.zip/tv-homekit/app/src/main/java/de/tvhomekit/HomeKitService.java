package de.tvhomekit;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.wifi.WifiManager;
import android.os.IBinder;
import android.util.Log;
import io.github.hapjava.server.impl.HomekitServer;
import java.io.IOException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class HomeKitService extends Service {
    private static final String TAG = "TvHomeKit";
    private volatile boolean started = false;
    private HomekitServer server;
    private WifiManager.MulticastLock lock;

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (started) return START_STICKY;
        started = true;
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(
                new NotificationChannel("tvhk", "HomeKit", NotificationManager.IMPORTANCE_LOW));
        startForeground(1, new Notification.Builder(this, "tvhk")
                .setContentTitle("HomeKit-Bridge laeuft")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .build());
        new Thread(this::startServer, "hap-start").start();
        return START_STICKY;
    }

    private void startServer() {
        Status.server = "startet ...";
        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
            lock = wm.createMulticastLock("tvhk");
            lock.setReferenceCounted(false);
            lock.acquire();

            SharedPreferences p = getSharedPreferences("tvhk", MODE_PRIVATE);
            SonyTv tv = new SonyTv(p.getString("host", "127.0.0.1"), p.getString("psk", ""));

            InetAddress addr = localAddress();
            server = new HomekitServer(addr, 9123);
            io.github.hapjava.server.impl.HomekitStandaloneAccessoryServer r =
                    server.createStandaloneAccessory(new PrefsAuthInfo(this), new TvSwitch(tv));
            r.start();
            String t = new SimpleDateFormat("HH:mm:ss", Locale.GERMANY).format(new Date());
            Status.server = "laeuft seit " + t + " auf " + addr.getHostAddress() + ":9123";
            Log.i(TAG, Status.server);
        } catch (Throwable e) {
            Status.server = "FEHLER: " + e;
            Log.e(TAG, "Start fehlgeschlagen", e);
        }
    }

    /** Waehlt die LAN-Adresse (bevorzugt WLAN/Ethernet) und merkt alle gefundenen Adressen fuer die Anzeige. */
    private static InetAddress localAddress() throws IOException {
        InetAddress preferred = null;
        InetAddress fallback = null;
        List<String> all = new ArrayList<>();
        for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
            if (!ni.isUp() || ni.isLoopback()) continue;
            for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                if (!(a instanceof Inet4Address) || !a.isSiteLocalAddress()) continue;
                all.add(ni.getName() + "=" + a.getHostAddress());
                String n = ni.getName();
                if (preferred == null && (n.startsWith("wlan0") || n.startsWith("eth"))) preferred = a;
                if (fallback == null) fallback = a;
            }
        }
        Status.ifaces = all.isEmpty() ? "keine gefunden" : android.text.TextUtils.join(", ", all);
        InetAddress result = preferred != null ? preferred : fallback;
        if (result == null) throw new IOException("Keine lokale IPv4-Adresse gefunden");
        return result;
    }

    @Override
    public void onDestroy() {
        try {
            if (server != null) server.stop();
        } catch (Throwable ignored) { }
        if (lock != null && lock.isHeld()) lock.release();
        super.onDestroy();
    }
}
