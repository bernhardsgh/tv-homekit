package de.tvhomekit;

import io.github.hapjava.accessories.SwitchAccessory;
import io.github.hapjava.characteristics.HomekitCharacteristicChangeCallback;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/** Der Fernseher als HomeKit-Schalter. Der Zustand wird im Hintergrund abgefragt und gemerkt,
 *  damit HomeKit nie auf eine langsame TV-Antwort warten muss. */
public class TvSwitch implements SwitchAccessory {
    private final SonyTv tv;
    private volatile HomekitCharacteristicChangeCallback callback;
    private volatile boolean lastState;
    private final ScheduledExecutorService poller = Executors.newSingleThreadScheduledExecutor();

    public TvSwitch(SonyTv tv) {
        this.tv = tv;
        poller.scheduleWithFixedDelay(() -> {
            try {
                boolean now = tv.isOn();
                if (now != lastState) {
                    lastState = now;
                    HomekitCharacteristicChangeCallback cb = callback;
                    if (cb != null) cb.changed();
                }
            } catch (Exception ignored) { }
        }, 1, 5, TimeUnit.SECONDS);
    }

    public int getId() { return 2; }
    public CompletableFuture<String> getName() { return CompletableFuture.completedFuture("Fernseher"); }
    public void identify() { }
    public CompletableFuture<String> getSerialNumber() { return CompletableFuture.completedFuture("TVHK-0001"); }
    public CompletableFuture<String> getModel() { return CompletableFuture.completedFuture("Bravia Bridge"); }
    public CompletableFuture<String> getManufacturer() { return CompletableFuture.completedFuture("Eigenbau"); }
    public CompletableFuture<String> getFirmwareRevision() { return CompletableFuture.completedFuture("0.2"); }

    public CompletableFuture<Boolean> getSwitchState() {
        return CompletableFuture.completedFuture(lastState);
    }

    public CompletableFuture<Void> setSwitchState(boolean state) {
        lastState = state;
        return CompletableFuture.runAsync(() -> {
            try { tv.setOn(state); } catch (Exception ignored) { }
        });
    }

    public void subscribeSwitchState(HomekitCharacteristicChangeCallback cb) { callback = cb; }
    public void unsubscribeSwitchState() { callback = null; }
}
