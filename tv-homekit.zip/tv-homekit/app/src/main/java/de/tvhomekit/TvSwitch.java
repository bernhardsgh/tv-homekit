package de.tvhomekit;

import io.github.hapjava.accessories.SwitchAccessory;
import io.github.hapjava.characteristics.HomekitCharacteristicChangeCallback;
import java.io.IOException;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/** Der Fernseher als HomeKit-Schalter (Stufe 1). */
public class TvSwitch implements SwitchAccessory {
    private final SonyTv tv;
    private volatile HomekitCharacteristicChangeCallback callback;
    private volatile boolean lastState;
    private final ScheduledExecutorService poller = Executors.newSingleThreadScheduledExecutor();

    public TvSwitch(SonyTv tv) {
        this.tv = tv;
        poller.scheduleWithFixedDelay(() -> {
            try {
                boolean now = tv.isOn();
                if (now != lastState) {
                    lastState = now;
                    HomekitCharacteristicChangeCallback cb = callback;
                    if (cb != null) cb.changed();
                }
            } catch (IOException ignored) { }
        }, 5, 10, TimeUnit.SECONDS);
    }

    public int getId() { return 2; }
    public CompletableFuture<String> getName() { return CompletableFuture.completedFuture("Fernseher"); }
    public void identify() { }
    public CompletableFuture<String> getSerialNumber() { return CompletableFuture.completedFuture("TVHK-0001"); }
    public CompletableFuture<String> getModel() { return CompletableFuture.completedFuture("Bravia Bridge"); }
    public CompletableFuture<String> getManufacturer() { return CompletableFuture.completedFuture("Eigenbau"); }
    public CompletableFuture<String> getFirmwareRevision() { return CompletableFuture.completedFuture("0.1"); }

    public CompletableFuture<Boolean> getSwitchState() {
        return CompletableFuture.supplyAsync(() -> {
            try { lastState = tv.isOn(); } catch (IOException e) { lastState = false; }
            return lastState;
        });
    }

    public CompletableFuture<Void> setSwitchState(boolean state) {
        return CompletableFuture.runAsync(() -> {
            try { tv.setOn(state); lastState = state; } catch (IOException ignored) { }
        });
    }

    public void subscribeSwitchState(HomekitCharacteristicChangeCallback cb) { callback = cb; }
    public void unsubscribeSwitchState() { callback = null; }
}
