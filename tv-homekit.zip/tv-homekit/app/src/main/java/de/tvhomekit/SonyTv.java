package de.tvhomekit;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Steuerung ueber die Sony-BRAVIA-IP-Steuerung (REST, Pre-Shared Key). */
public class SonyTv {
    private final String host;
    private final String psk;

    public SonyTv(String host, String psk) {
        this.host = host;
        this.psk = psk;
    }

    private String call(String method, String params) throws IOException {
        URL url = new URL("http://" + host + "/sony/system");
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setRequestMethod("POST");
        c.setRequestProperty("X-Auth-PSK", psk);
        c.setRequestProperty("Content-Type", "application/json");
        c.setConnectTimeout(2000);
        c.setReadTimeout(3000);
        c.setDoOutput(true);
        String body = "{\"method\":\"" + method + "\",\"id\":1,\"params\":[" + params
                + "],\"version\":\"1.0\"}";
        try (OutputStream os = c.getOutputStream()) {
            os.write(body.getBytes(StandardCharsets.UTF_8));
        }
        try (InputStream in = c.getInputStream()) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[1024];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toString("UTF-8");
        } finally {
            c.disconnect();
        }
    }

    public boolean isOn() throws IOException {
        try {
            boolean on = call("getPowerStatus", "").contains("\"active\"");
            Status.tv = "ok (TV ist " + (on ? "an" : "aus") + ") via " + host;
            return on;
        } catch (IOException e) {
            Status.tv = "Fehler bei " + host + ": " + e.getMessage();
            throw e;
        }
    }

    public void setOn(boolean on) throws IOException {
        try {
            call("setPowerStatus", "{\"status\":" + on + "}");
            Status.tv = "ok (Befehl " + (on ? "an" : "aus") + " gesendet) via " + host;
        } catch (IOException e) {
            Status.tv = "Fehler bei " + host + ": " + e.getMessage();
            throw e;
        }
    }
}
