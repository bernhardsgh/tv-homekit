# TV HomeKit (Stufe 1: Fernseher als HomeKit-Schalter)

1. Projekt in Android Studio oeffnen (Ordner tv-homekit), Gradle-Sync abwarten.
2. Build > Build APK(s).
3. TV: Entwickleroptionen > Netzwerk-Debugging an, dann:
   adb connect <TV-IP>:5555
   adb install app/build/outputs/apk/debug/app-debug.apk
   adb shell am start -n de.tvhomekit/.MainActivity
4. In der App den Pre-Shared Key der Sony-IP-Steuerung eintragen, "Speichern & starten".
5. iPhone: Home-App > + > Geraet hinzufuegen > QR-Code vom TV scannen
   (Hinweis "Nicht zertifiziertes Geraet" bestaetigen).
